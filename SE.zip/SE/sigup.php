<!DOCTYPE html>
<html>
  <head>
    <title>Registration Page</title> 
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="css/login.css"/>
  </head>
  <body>
    <div class="bg-img">
        <div class="content">
            <header>Sign Up</header>
            <form action="connect.php" method="post">
                <div class="field name">
                    <span class="fa-sharp fa-solid fa-address-card"></span>
                    <input type="text" id="firstName" name="firstName" placeholder="First Name">
                </div>
                <div class="field name">
                    <span class="fa-sharp fa-solid fa-address-card"></span>
                    <input type="text" class="form-control" id="lastName" name="lastName" required placeholder="Last Name">
                </div>
                <div class="field email">
                    <span class="fa-solid fa-envelope"></span>
                    <input id="email" name="email" type="text" required placeholder="Enter Your Email">
                </div>
                <div class="field">
                    <span class="fa fa-user"></span>
                    <input  id="uname" class="form-control" name="uname" type="text" required placeholder="Enter Username"/>
                </div>
                <div class="field space">
                    <span class="fa fa-lock"></span>
                    <input type="password" class="password" id="password" name="password" required placeholder="Enter Password" />
                </div>
                <div class="bsubmit">
                    <button class="submit" type="submit">Sign Up</button>
                </div>
            </form>
          </div>
        </div>
  </body>
</html>