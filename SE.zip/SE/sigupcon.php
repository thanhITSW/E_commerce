<?php
	$firstName = $_POST['firstName'];
	$lastName = $_POST['lastName'];
	$email = $_POST['email'];
	$uname = $_POST['uname'];
	$password = $_POST['password'];

	// Database connection
	$conn = new mysqli('localhost','root','','harper');
	if($conn->connect_error){
		echo "$conn->connect_error";
		die("Connection Failed : ". $conn->connect_error);
	}

	if(!isset($_POST['firstName'], $_POST['lastName'], $_POST['email'], $_POST['uname'], $_POST['password'])) {
		exit("Empty Field");
	}

	if(empty($_POST['firstName'] || empty($_POST['lastName']) || empty($_POST['email']) || empty($_POST['uname']) || empty($_POST['password']))) {
		exit('Value Empty');
	}

	

	if ($stmt = $conn->prepare('SELECT id, password FROM users WHERE uname = ?')) {
		$stmt->bind_param('s', $_POST['$uname']);
		$stmt->execute();
		$stmt->store_result();

		if($stmt->num_rows>0) {
			echo 'Username Already Exists. Try Again';
		}
		else {
			if($stmt = $conn->prepare("insert into users(firstName, lastName, email, uname, password) values(?, ?, ?, ?, ?)")) {
			$password = password_hash($_POST['password'], PASSWORD_DEFAULT);
			$stmt->bind_param('sssss',$firstName, $lastName, $email, $uname, $password);
			$stmt->execute();
			echo 'Succesfully Signup';
			}
			else {
				echo 'Error Occurred';
			}
		}
		$stmt->close();
	}
	else {
		echo'Error';
	}

	var_dump($password)


	
	?>
